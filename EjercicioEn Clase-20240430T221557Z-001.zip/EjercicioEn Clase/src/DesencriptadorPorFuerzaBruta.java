public class DesencriptadorPorFuerzaBruta {
    Desencriptador desencriptador = new Desencriptador();

    String desencriptarPorFuerzaBruta(String textoEncriptado) {
        String textoPosiblementeDesencriptado = "nada por aqui";

        for (int i = 1; i < 10; i++){
            textoPosiblementeDesencriptadop = desencriptador.desencriptar(textoEncriptado, i);

            boolean contienePalabraEnESpanol = contieneAlgunaPalabraEnEspanol(textoPosiblementeDesencriptado);
            if (contienePalabraEnEspanol){
                System.out.println("La clave es:" + i);
                System.out.println("Y el texto desencriptado es:" + textoPosiblementeDesencriptado);
            }
        }

        return textoPosiblemteDesencriptado;
    }
    boolean contienAlgunaPalabraEnESpanol(Strin texto){
        String[] palabrasEnEspanol = new String[4];
        palabrasEnESpanol [0] = " de ";
        palabrasEnESpanol [1] = " en ";
        palabrasEnESpanol [2] = " el ";
        palabrasEnESpanol [3] = " la ";

        for (int i = 0; i < palabrasEnEspano.length(); i++){
            if (texto.contains(palabrasEnEspanol[i])){
                return true;
            }
        }
        return false;

    }
}
